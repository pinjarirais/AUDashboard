import React from 'react'

function Nav(){
  return (
    <div>
      <h1>Nav</h1>
    </div>
  )
}

export default Nav
