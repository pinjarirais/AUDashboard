import React from 'react'

function Footer() {
  return (
    <div className='bg-[#6d3078] fixed inset-x-0 bottom-0 px-10 py-3'>
      <p className='text-white'>© Copyright AU Small Finance Bank Limited</p>
    </div>
  )
}

export default Footer
