import React from 'react'


function Details() {
  return (
    <>
      <h1>CH User Details</h1>
     
    

    </>
  )
}

export default Details
