import React from 'react'
import ExcelUploader from '../../component/UploadXcl'

function UploadData() {
  return (
    <>
      <ExcelUploader />
    </>
  )
}

export default UploadData
